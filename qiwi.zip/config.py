telegram_token = 'telegram_token'

admin = 1546182461